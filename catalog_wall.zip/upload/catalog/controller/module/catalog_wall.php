<?php
class ControllerModuleCatalogWall extends Controller {
	public function index($setting) {
		#$this->load->language('module/latest');

		/*$data['heading_title'] = $this->language->get('heading_title');

		$data['text_tax'] = $this->language->get('text_tax');

		$data['button_cart'] = $this->language->get('button_cart');
		$data['button_wishlist'] = $this->language->get('button_wishlist');
		$data['button_compare'] = $this->language->get('button_compare');*/

		$this->load->model('catalog/category');

		$categories = $this->model_catalog_category->getCategories(0);

		foreach ($categories as $category) {
	      if ($category['top']) {
	        // Level 2
	        $children_data = array();

	        $children = $this->model_catalog_category->getCategories($category['category_id']);

	        foreach ($children as $child) {
	          $filter_data = array(
	            'filter_category_id'  => $child['category_id'],
	            'filter_sub_category' => true
	          );
	          $children_data[] = array(
	            'name'  => $child['name'],
	            'href'  => $this->url->link('product/category', 'path=' . $category['category_id'] . '_' . $child['category_id']),
	            'image' => (empty($child['image'])) ? "" : '/image/'.$child['image']
	          );
	        }

	        // Level 1
	        $data['categories'][] = array(
	          'name'     => $category['name'],
	          'children' => $children_data,
	          'column'   => $category['column'] ? $category['column'] : 1,
	          'href'     => $this->url->link('product/category', 'path=' . $category['category_id']),
	          'image' 	 => '/image/'.$category['image']
	        );
	      }
	    }

		if (file_exists(DIR_TEMPLATE . $this->config->get('config_template') . '/template/module/catalog_wall.tpl')) {
			return $this->load->view($this->config->get('config_template') . '/template/module/catalog_wall.tpl', $data);
		} else {
			return $this->load->view('default/template/module/catalog_wall.tpl', $data);
		}

	}

}
